<template>
	<v-container fluid class="home pa-0 ">
		<div class=" white--text blue home-top py-5 px-8">
			<!-- lang/menu bar -->
			<HomeTop />
			<!-- main info -->
			<HomeCenter :weather="weather" :icons="weatherIcons" />
		</div>
		<!-- bottom nav-->
		<HomeBottom :weather="weather" :icons="weatherIcons" />
	</v-container>
</template>

<script>
// @ is an alias to /src
import HomeBottom from "@/components/HomeBottom";
import HomeCenter from "@/components/HomeCenter";
import HomeTop from "@/components/HomeTop";

export default {
	name: "home",
	mounted() {
		this.$store.dispatch("getWeather");
	},
	components: {
		HomeBottom,
		HomeCenter,
		HomeTop,
		
	},
	computed: {
		weather() {
			return this.$store.getters.get_weather;
		},
		get_loading_status() {
			return this.$store.getters.get_loading_status;
		},
		weatherIcons() {
			return this.$store.getters.get_weather_icons;
		}
	},
	data: () => ({})
};
</script>
<style lang="scss" scoped>
.home-top {
	height: 70vh;
}
</style>
