<template>
	<v-card height="100%">
		<v-toolbar color="blue" dark flat>
			<v-btn icon to="/">
				<v-icon>{{ iconArrow }}</v-icon>
			</v-btn>
			<v-toolbar-title>Europe/Kiev </v-toolbar-title>

			<v-spacer></v-spacer>

			<div class="d-flex">
				<div class="caption text-uppercase">
					ru
				</div>
				<v-menu offset-y>
					<template v-slot:activator="{ on }">
						<v-btn icon v-on="on">
							<v-icon>{{ iconLang }}</v-icon>
						</v-btn>
					</template>
					<v-list>
						<v-list-item v-for="(item, index) in menuItems" :key="index">
							<v-list-item-title>{{ item.title }}</v-list-item-title>
						</v-list-item>
					</v-list>
				</v-menu>
			</div>

			<template v-slot:extension>
				<v-tabs
					v-model="tabs"
					class="mb-0"
					align-with-title
					background-color="transparent"
				>
					<v-tabs-slider></v-tabs-slider>

					<v-tab v-for="item in items" :key="item">
						{{ item }}
					</v-tab>
				</v-tabs>
			</template>
		</v-toolbar>

		<v-tabs-items v-model="tabs">
			<v-tab-item>
				<DailySummary
					v-if="!loading"
					:weather="dailyWeather.currently"
					:langData="this.get_lang_data"
					:icons="get_icons"
				/>
			</v-tab-item>
			<v-tab-item>
				<DailyDetails
					:hourly="dailyWeather.hourly"
					v-if="!loading"
					:langData="this.get_lang_data"
					:icons="get_icons"
				/>
			</v-tab-item>
		</v-tabs-items>
	</v-card>
	<!-- <v-app-bar color="blue" dark shrink-on-scroll prominent hide-on-scroll>
      <v-btn icon>
        <v-icon>{{ iconArrow }}</v-icon>
      </v-btn>
      <v-toolbar-title>Title</v-toolbar-title>
    </v-app-bar> -->
	<!-- <DailySummary /> -->
</template>
<script>
import DailySummary from "@/components/DailySummary";
import DailyDetails from "@/components/DailyDetails";

import { mdiArrowLeft, mdiWeb } from "@mdi/js";
export default {
	components: { DailySummary, DailyDetails },
	props: { time: Object },
	mounted() {
		this.$store.dispatch("getDailyWeather", this.time);
	},
	computed: {
		get_lang_data() {
			return this.$store.getters.get_lang_data;
		},
		dailyWeather() {
			return this.$store.getters.get_daily;
		},
		loading() {
			return this.$store.getters.get_daily_loading;
		},
		get_icons() {
			return this.$store.getters.get_icons;
		}
	},
	data: () => ({
		tabs: null,
		name: "daily",
		items: ["Summary", "Details"],
		menuItems: [{ title: "ru" }, { title: "en" }],
		iconLang: mdiWeb,
		iconArrow: mdiArrowLeft
	})
};
// Сумарное описание
// Температура
// Температура ощущается
// вероятность осадков
// скорость ветра
// влажность
</script>
