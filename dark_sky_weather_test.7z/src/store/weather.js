import axios from "axios";
import en from "@/assets/lang/en.json";
import ru from "@/assets/lang/ru.json";

export default {
	state: {
		lang: "en",
		loading: false,
		weather: {},
		langData: { en, ru }
	},
	getters: {
		get_weather(state) {
			return state.weather;
		},
		get_loading_status(state) {
			return state.loading;
		},
		get_lang_data: state => {
			return state.langData[state.lang];
		},
		get_lang: state => {
			return state.lang;
		}
	},
	mutations: {
		SET_LANG(state, payload) {
			state.lang = payload;
		},
		SET_WEATHER(state, payload) {
			state.weather = payload;
		},
		SET_LOADING_STATUS(state, payload) {
			state.loading = payload;
		}
	},
	actions: {
		async getWeather({ commit, state }) {
			commit("SET_LOADING_STATUS", true);
			try {
				let url =
					"https://api.darksky.net/forecast/770bf1dd799873b06dc56454496e4c45/46.444003,30.748728?lang=" +
					state.lang +
					"&units=si&exclude=flags,hourly";
				// Прокси добавил в связи с тем, что по какой-то причине при запросе на сервер получаю CORS ошибку.
				let proxy = "https://cors-anywhere.herokuapp.com/";
				const response = await axios.get(proxy + url);
				console.log(response);
				commit("SET_WEATHER", response.data);
				commit("SET_LOADING_STATUS", false);
			} catch (e) {
				console.log(e);
			}
		},
		changeLanguage({ commit }) {
			commit("SET_WEATHER_LANGUAGE");
		}
	}
};
