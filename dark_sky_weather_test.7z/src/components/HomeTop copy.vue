<template>
  <v-row class="home__menu" align='center'>
    <div class="font-weight-bold">Europe/Kiev</div>
    <v-spacer></v-spacer>
    <!-- <div class="home__langbar" align="flex-end"> -->
    <div class="d-flex">
      <div class="caption text-uppercase">
        ru
      </div>
      <v-btn dark icon v-on="on">
        <v-icon class="" color="white">{{ iconlang }}</v-icon>
      </v-btn>
    </div>

    <!-- <span class="font-weight-bold">ru</span> -->
    <!-- </div> -->

    <v-menu
      v-model="showMenu"
    >
      <v-list>
        <v-list-item v-for="(item, index) in items" :key="index">
          <v-list-item-title>{{ item.title }}</v-list-item-title>
        </v-list-item>
      </v-list>
    </v-menu>
  </v-row>
</template>
<script>
import { mdiWeb } from "@mdi/js";
export default {
  data: () => ({
    showMenu: false,
    iconlang: mdiWeb,
    items: [{ title: "ru" }, { title: "en" }, { title: "ua" }]
  }),
  methods: {
    show(e) {
      e.preventDefault();
      this.showMenu = false;
      this.x = e.clientX;
      this.y = e.clientY;
      this.$nextTick(() => {
        this.showMenu = true;
      });
    }
  }
};
</script>
<style lang="scss" scoped>
.home__menu {
  .home__langbar {
    cursor: pointer;
    span {
      text-transform: uppercase;
    }
  }
}
</style>
