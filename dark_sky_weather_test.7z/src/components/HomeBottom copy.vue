<template>
  <!-- <div
    class="font-weight-light d-flex"
    elevation="1"
    max-width=""
    max-height=""
  > -->
  <v-slide-group v-model="model" show-arrows max-width="200" center-active>
    <v-slide-item v-for="n in 7" :key="n" v-slot:default="{ active, toggle }">
      <v-card class="my-3 mx-1 px-1 " width="100" @click="toggle">
             <v-card-title>
            Sat
          </v-card-title>
          <v-card-subtitle>Occasional rain and drizle </v-card-subtitle>
          <v-card-icon
            ><v-icon size="33px">{{ iconSunny }}</v-icon></v-card-icon
          >
          <v-card-text>17°/18°</v-card-text>
      </v-card>
    </v-slide-item>
    <v-slide-item v-slot:default="{ active, toggle }">
      <v-col sm="2">
        <v-card
          class="my-3 mx-1 px-1 d-flex flex-column align-center justify-space-between"
          @click="toggle"
        >
          <v-card-title>
            Sat
          </v-card-title>
          <v-card-subtitle>Occasional rain and drizle </v-card-subtitle>
          <v-card-icon
            ><v-icon size="33px">{{ iconSunny }}</v-icon></v-card-icon
          >
          <v-card-text>17°/18°</v-card-text>
        </v-card></v-col
      >
    </v-slide-item>
    <v-slide-item v-slot:default="{ active, toggle }">
      <v-col sm="2">
        <v-card
          class="my-3 mx-1 px-1 d-flex flex-column align-center justify-space-between"
          @click="toggle"
        >
          <v-card-title>
            Sat
          </v-card-title>
          <v-card-subtitle>Occasional rain and drizle </v-card-subtitle>
          <v-card-icon
            ><v-icon size="33px">{{ iconSunny }}</v-icon></v-card-icon
          >
          <v-card-text>17°/18°</v-card-text>
        </v-card></v-col
      >
    </v-slide-item>
  </v-slide-group>
  <!-- </div> -->
</template>
<script>
import { mdiWhiteBalanceSunny } from "@mdi/js";
export default {
  data: () => ({
    iconSunny: mdiWhiteBalanceSunny
  })
};
</script>
