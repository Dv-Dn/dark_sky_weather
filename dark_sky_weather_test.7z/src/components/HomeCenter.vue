<template>
  <v-container justify="center">
    <div>
      <v-row class="home__main">
        <span class="font-weight-thin display-4">{{
          Math.round(weather.currently.temperature) + "°"
        }}</span>
        <v-icon class="pt-11 ml-2" color="white" size="50px">
          {{ icons[weather.currently.icon] }}
        </v-icon>
      </v-row>
      <v-row>
        <p>
          <!-- 20° / 7° -->
          {{
            weather.daily.data[0].temperatureHigh.toFixed(0) +
              "° / " +
              weather.daily.data[0].temperatureLow.toFixed(0) +
              "°"
          }}
        </p>
        <p class="pl-3 mb-0">
          <v-icon class="pb-1 mr-1" color="white" size="18px">{{
            iconBody
          }}</v-icon
          >{{ weather.currently.apparentTemperature.toFixed(0) }}°
        </p>
      </v-row>
      <v-row class="pb-3">
        {{ weather.currently.summary }}
      </v-row>
      <v-row
        ><p>
          <v-icon class="pb-1 mr-1 ml-n1" color="white" size="18px">{{
            iconWater
          }}</v-icon
          >{{ weather.currently.humidity * 100 }} %
        </p>
        <p class="ml-4">
          <v-icon class="pb-1 mr-1" color="white" size="18px">{{
            iconWind
          }}</v-icon
          >{{ weather.currently.windSpeed.toFixed(1) }} m/s
        </p>
        <p class="ml-4">
          <v-icon class="pb-1 mr-1" color="white" size="18px">{{
            iconPrecipitation
          }}</v-icon
          >{{ weather.currently.precipProbability.toFixed(1) }}%
        </p>
      </v-row>
      <v-row>
        <p class="">
          Show more
          <v-icon class="pb-1 mr-1" color="white">{{ iconArrowDown }}</v-icon>
        </p>
      </v-row>
    </div>
  </v-container>
</template>
<script>
import {
  mdiWhiteBalanceSunny,
  mdiTshirtCrew,
  mdiWater,
  mdiArrowDownDropCircleOutline,
  mdiChevronLeft,
  mdiChevronRight,
  // weather icons
  mdiWeatherWindy,
  mdiCloudQuestion
} from "@mdi/js";
export default {
  props: { weather: Object, icons: Object },
  data: () => ({
    iconSun: mdiWhiteBalanceSunny,
    iconBody: mdiTshirtCrew,
    iconWater: mdiWater,
    iconWind: mdiWeatherWindy,
    iconPrecipitation: mdiCloudQuestion,
    iconArrowDown: mdiArrowDownDropCircleOutline,
    iconPrev: mdiChevronLeft,
    iconNext: mdiChevronRight
  })
};
</script>
