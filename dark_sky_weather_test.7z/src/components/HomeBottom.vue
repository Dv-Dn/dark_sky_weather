<template>
  <!-- <div
    class="font-weight-light d-flex"
    elevation="1"
    max-width=""
    max-height=""
  > -->
  <v-slide-group v-model="model" show-arrows max-width="200" center-active>
    <v-slide-item
      v-for="n in weather.daily.data"
      :key="n.time"
      v-slot:default="{ active, toggle }"
    >
      <!-- <v-col cols="1" sm="2" tag="div"> -->
      <!-- class="my-3 mx-1 px-1 d-flex flex-column justify-space-between" -->
      <v-card
        class="d-flex flex-column justify-space-between mx-3 my-3"
        width="200"
        @click="toggle"
        height="200"
        justify="space-between"
        :to="{ name: 'daily', params: { time: n.time } }"
      >
        <v-card-title class="mx-auto">
          {{ convertTime(n.time) }}
          <!-- Sat -->
        </v-card-title>
        <v-card-subtitle :style="{ height: '70px' }"
          >{{ n.summary }}
        </v-card-subtitle>
        <div>
          <v-icon size="33px">{{ icons[n.icon] }}</v-icon>
        </div>
        <v-card-text>{{
          Math.round(n.temperatureLow) +
            "°/ " +
            Math.round(n.temperatureHigh) +
            "°"
        }}</v-card-text>
      </v-card>
      <!-- </v-col> -->
    </v-slide-item>
  </v-slide-group>
  <!-- </div> -->
</template>
<script>
import { mdiWhiteBalanceSunny } from "@mdi/js";
export default {
  props: { weather: Object, icons: Object },

  data: () => ({
    model: 0,
    iconSunny: mdiWhiteBalanceSunny
  }),
  methods: {
    // calcTime(date) {
    //   // let d = new Date(q),
    //   //   utc = d.getTime() + d.getTimezoneOffset() * 60000,
    //   //   nd = new Date(utc + 3600000 * offset);
    //   // return nd;
    //   // console.log(date.getTimezoneOffset());
    // },
    convertTime(d) {
      let date = new Date(d * 1000);
      // console.log(date);
      let day = date.getDay();
      let days = [
        "Sunday",
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday"
      ];
      return days[day];
      // var date = new Date(1313564400000);
      // let month = date.getMonth();
      // console.log(date);
      // return month;
    }
  }
};
</script>
