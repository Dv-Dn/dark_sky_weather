<template>
	<v-row class="home__menu" align="center">
		<div class="font-weight-bold">Europe/Kiev</div>
		<v-spacer></v-spacer>

		<div class="d-flex">
			<div class="caption text-uppercase">
				ru
			</div>
			<!--  -->
			<v-menu offset-y>
				<template v-slot:activator="{ on }">
					<v-btn icon dark v-on="on">
						<v-icon class="" color="white">{{ iconlang }}</v-icon>
					</v-btn>
				</template>
				<v-list>
					<v-list-item v-for="(item, index) in items" :key="index">
						<v-list-item-title>{{ item.title }}</v-list-item-title>
					</v-list-item>
				</v-list>
			</v-menu>
		</div>
	</v-row>
</template>
<script>
import { mdiWeb } from "@mdi/js";
export default {
	data: () => ({
		showMenu: false,
		iconlang: mdiWeb,
		items: [{ title: "ru" }, { title: "en" }, { title: "ua" }]
	}),
	methods: {
		show(e) {
			e.preventDefault();
			this.showMenu = false;
			this.x = e.clientX;
			this.y = e.clientY;
			this.$nextTick(() => {
				this.showMenu = true;
			});
		}
	}
};
</script>
<style lang="scss" scoped>
.home__menu {
	.home__langbar {
		cursor: pointer;
		span {
			text-transform: uppercase;
		}
	}
}
</style>
